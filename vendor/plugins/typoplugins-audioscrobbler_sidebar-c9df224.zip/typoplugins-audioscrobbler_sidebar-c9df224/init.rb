require 'sidebar'
require 'audioscrobbler_sidebar'

AudioscrobblerSidebar.view_root = File.dirname(__FILE__) + '/views'

